#include "player.hpp"

Player::Player()
{
    health = 30;
    num_gems = 0;
}

void Player::set_health(int health) { this->health = health; }
int Player::get_health() { return health; }

void Player::set_num_gems(int num_gems) { this->num_gems = num_gems; }
int Player::get_num_gems() { return num_gems; }

void Player::dealt_damage(int damage)
{
    health -= damage;
}

void Player::add_gem()
{
    gems.push("Gem");
    num_gems++;
}

void Player::print_gems()
{
    cout << "\nPouch: ";

    for(int i = 0; i < num_gems; i++)
    {
        cout << "Gem ";
    }

    cout << endl;
}

void Player::print_total_gems()
{
    while(!gems.empty())
    {
        cout << gems.front() << " ";
        gems.pop();
    }

    cout << endl;
}