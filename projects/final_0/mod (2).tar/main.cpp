#include "game.hpp"

bool try_game_again() {
    int again;

    do {
        cout << "\nDo you want to play again?" << endl;
        cout << "\t1) Yes" << endl;
        cout << "\t2) No" << endl;
        cout << "Enter: ";
        cin >> again;

        if (cin.fail() || again < 1 || again > 2) {
            cout << "\nPlease try again." << endl;
            cin.clear();
            cin.ignore(9999, '\n');
        } else if (again == 2) {
            cout << "\nBye bye!" << endl;
            return false;
        } else if (again == 1) {
            return true;
        }

    } while (cin.fail() || again < 1 || again > 2);
}

int main() {
    srand(time(NULL));

    Game *g = NULL;

    do {
        g = new Game();
        g->beginning();
        delete g;
    } while (g->is_done() && try_game_again());

    return 0;
}