#ifndef HIGHEST_HPP
#define HIGHEST_HPP

#include "spaces.hpp"

class Highest : public Space //subclass of Space
{
    private:
        int place;

    public:
        Highest();

        int special(Player& knight);
        void validation();
};

#endif