#ifndef GATES_HPP
#define GATES_HPP

#include "spaces.hpp"

class Gates : public Space  //subclass of Space
{
    private:
        int pull;
        
    public:
        Gates();

        int special(Player& knight);
        void validation();
};

#endif