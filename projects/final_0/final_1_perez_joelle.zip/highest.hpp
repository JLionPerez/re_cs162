#ifndef HIGHEST_HPP
#define HIGHEST_HPP

#include "spaces.hpp"

class Highest : public Space //subclass of Space
{
    private:
        int place;

    public:
        Highest();

        void special(Player& knight);
        void validation();
};

#endif