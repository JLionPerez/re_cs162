#include "game.hpp"

int main()
{
    srand(time(NULL));

    Game g;
    g.beginning();

    return 0;
}