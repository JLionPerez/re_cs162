#include "spaces.hpp"

Space::Space()
{
    top = NULL;
    bottom = NULL;
    left = NULL;
    right = NULL;
    went_back = false;
    name = "";
    passed = false;
}

Space::~Space()
{
    //delete top;
    //delete bottom;
    //delete left;
    //delete right;
}

void Space::set_went_back(bool went_back) { this->went_back = went_back; }
bool Space::get_went_back() { return went_back; }

void Space::set_top(Space* top) { this->top = top; }
Space* Space::get_top() { return top; }

void Space::set_bottom(Space* bottom) { this->bottom = bottom; }
Space* Space::get_bottom() { return bottom; }

void Space::set_left(Space* left) { this->left = left; }
Space* Space::get_left() { return left; }

void Space::set_right(Space* right) { this->right = right; }
Space* Space::get_right() { return right; }

void Space::set_name(string name) { this->name = name; }
string Space::get_name() { return name; }

void Space::set_passed(bool passed) { this->passed = passed; }
bool Space::get_passed() { return passed; }