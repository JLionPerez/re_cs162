/*
* File name: tiger.hpp
* Purpose: Holds prototypes for tiger.cpp
*/

#ifndef TIGER_HPP
#define TIGER_HPP
#include "animal.hpp"

class Tiger : public Animal
{
    public:
        Tiger();
};

#endif