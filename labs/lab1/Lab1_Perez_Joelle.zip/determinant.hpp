#ifndef DETERMINANT_HPP
#define DETERMINANT_HPP

#include <iostream>
using std::cout;
using std::cin;
using std::endl;

int determinant(double** arr, int size);

#endif