#ifndef READ_MATRIX_HPP
#define READ_MATRIX_HPP

#include <iostream>
using std::cout;
using std::cin;
using std::endl;

#include <cstdlib>

void readMatrix(double** &arr, int size);

#endif