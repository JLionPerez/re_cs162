/*
* Name of Program: Lab 3 - War Game with Dice
* Author: Joelle Perez
* Date: 27 January 2019
* Purpose: This program is a game where two players are invlolved, when one has a higher value they gain a point for the number of rounds.
*/
#include "die.hpp"
#include "loaded_die.hpp"
#include "game.hpp"

int main()
{
    Game g;

    g.start_menu();
    g.main_menu();
    //unfinished
}